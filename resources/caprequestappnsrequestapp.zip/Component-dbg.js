sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("caprequestapp.ns.requestapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);